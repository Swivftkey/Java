package cf.arjun.dev.snake;

import android.graphics.Rect;

public class SnakePiece {
    Position position;

    public SnakePiece (Position position) {
        this.position = position;
    }

}
